# Smart Healthcare Prediction System — Diabetes Risk Assessment

## Project Structure

```
diabetes_project/
├── data/
│   └── diabetes_raw.csv          # Dataset (UCI Diabetes 130-US Hospitals)
├── models/                        # Serialised trained models + preprocessing artifacts
│   ├── voting_classifier.pkl
│   ├── random_forest.pkl
│   ├── gradient_boosting.pkl
│   ├── adaboost.pkl
│   ├── scaler.pkl
│   ├── encoders.pkl
│   ├── feature_names.pkl
│   ├── cat_cols.pkl
│   └── num_feat.pkl
├── plots/                         # All EDA and evaluation plots (PNG)
│   ├── eda_missing_values.png
│   ├── eda_class_distribution.png
│   ├── eda_distributions.png
│   ├── eda_correlation_heatmap.png
│   ├── eda_outliers_boxplot.png
│   ├── feature_importance_rf.png
│   ├── confusion_matrices.png
│   ├── model_comparison.png
│   └── cv_comparison.png
├── webapp/
│   ├── app.py                     # Flask backend
│   └── templates/
│       └── index.html             # Frontend UI
├── report/
│   └── diabetes_risk_report.md    # Full formal report
├── pipeline.py                    # Full ML pipeline (run this first)
├── requirements.txt
└── README.md
```

## Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Generate dataset + train models
```bash
python pipeline.py
```

### 3. Start the web app
```bash
cd webapp
python app.py
# → Open http://localhost:5000
```

## Requirements
- Python 3.8+
- See requirements.txt

## Dataset
UCI ML Repository: https://archive.ics.uci.edu/dataset/296/diabetes+130-us+hospitals+for+years+1999-2008

Reference: Strack et al. (2014), BioMed Research International, DOI: 10.1155/2014/781670

## Models
| Model | Test F1 | CV F1 |
|-------|---------|-------|
| Random Forest | 0.5677 | 0.7073 |
| Gradient Boosting | 0.5992 | 0.7225 |
| AdaBoost | 0.4765 | 0.5701 |
| **Voting Classifier** | **0.6016** | 0.7196 |
